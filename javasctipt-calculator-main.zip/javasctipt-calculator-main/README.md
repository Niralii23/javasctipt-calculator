# javasctipt-calculator
i made javascipt calculator with three function scitific ,account and basic
